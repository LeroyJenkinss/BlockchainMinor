from Signature import *

class Tx:

    def add_input(self, from_addr, amount):
        pass

    def add_output(self, to_addr, amount):
        pass

    def add_reqd(self, addr):
        pass

    def sign(self, private):
        pass
               
    def is_valid(self):
        pass
